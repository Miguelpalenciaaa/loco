<?php
$version = "1.4.1 Beta: Diligent Bison";
$reldate = "May 31 2015";
$relyear = 2015;
